package com.penzzly.engine.core.utilites.tags;

import org.jetbrains.annotations.NotNull;

public interface Named {
	@NotNull String getName();
}
