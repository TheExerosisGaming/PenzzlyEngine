package com.penzzly.engine.core.utilites.color;
//TODO support translation between various Bukkit colors.