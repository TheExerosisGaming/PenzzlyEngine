package com.penzzly.engine.core.components.messaging;

import com.google.common.io.ByteStreams;
import com.penzzly.engine.architecture.base.Component;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

import java.io.DataInput;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import static com.penzzly.engine.core.utilites.bukkit.ServerUtil.*;

public class PluginMessagingComponent extends Component implements PluginMessageListener {
    private final List<BiConsumer<Player, DataInput>> messageListeners = new ArrayList<>();
    private final String channel;

    public PluginMessagingComponent(String channel) {
        this.channel = channel;
    }

    @Override
    public void onPluginMessageReceived(@NotNull String channel, Player player, @NotNull byte[] message) {
        if (channel.equals(this.channel))
            messageListeners.forEach(listener -> listener.accept(player, ByteStreams.newDataInput(message)));
    }

    public void onMessage(BiConsumer<Player, DataInput> listener) {
        messageListeners.add(listener);
    }
	
	public void sendMessage(@NotNull Player player, String... message) {
		sendPluginMessage(player, channel, message);
    }

/*    public void broadcastMessage(String... message) {
        broadcastPluginMessage(channel, message);
    }*/
	
	@NotNull
	public List<BiConsumer<Player, DataInput>> getMessageListeners() {
		return messageListeners;
	}

    @Override
    public Component enable() {
        registerChannel(channel, this);
        registerChannel(channel);
        return super.enable();
    }

    @Override
    public Component disable() {
        unregisterChannel(channel, this);
        unregisterChannel(channel);
        return super.disable();
    }
}
