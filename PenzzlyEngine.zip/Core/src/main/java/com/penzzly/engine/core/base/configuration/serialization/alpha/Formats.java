package com.penzzly.engine.core.base.configuration.serialization.alpha;

public class Formats {
}
