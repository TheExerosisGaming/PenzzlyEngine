package com.penzzly.engine.core.base;


import com.penzzly.engine.core.base.window.Display;
import com.penzzly.engine.core.base.window.Screen;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public interface Window {
	Map<Player, Screen> screens = new HashMap<>();
	
	static Display like(@NotNull BiConsumer<Screen, Player> description) {
		return new Display(player ->
				description.accept(screens.computeIfAbsent(player, Screen::new)
						.enable(), player), player -> screens.get(player).disable());
	}
}