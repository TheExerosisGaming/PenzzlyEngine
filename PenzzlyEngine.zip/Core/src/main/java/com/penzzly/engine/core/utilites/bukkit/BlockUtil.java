package com.penzzly.engine.core.utilites.bukkit;

import com.penzzly.engine.architecture.functions.Optional;
import org.apache.commons.lang.mutable.MutableInt;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.MaterialData;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.penzzly.engine.architecture.functions.Optional.empty;
import static com.penzzly.engine.architecture.functions.Optional.of;
import static com.penzzly.engine.core.utilites.functions.Functions.roundRobin;
import static java.lang.Math.round;
import static java.util.Comparator.reverseOrder;
import static java.util.Map.Entry.comparingByValue;
import static org.bukkit.block.BlockFace.*;

/**
 * Durpped in to existence by Exerosis on 3/17/2016.
 */
public class BlockUtil {
	
	private BlockUtil() {
	}
	
	public static ItemStack toItemStack(@NotNull Block block) {
		return toItemStack(block, 1);
	}
	
	public static ItemStack toItemStack(@NotNull Block block, int amount) {
		return toMaterialData(block).toItemStack(amount);
	}
	class Test implements ConfigurationSerializable {
		@Override
		public Map<String, Object> serialize() {
			return null;
		}
	}
	public static MaterialData toMaterialData(@NotNull Block block) {
		Map<Player, Integer> test = null;
		MutableInt index = new MutableInt();
		ConfigurationSerialization.registerClass();
		List<Map.Entry<Player, Integer>> winners = test.entrySet()
				.stream()
				.sorted(comparingByValue(reverseOrder()))
				.limit(4)
				.collect(Collectors.toList());
		for (int i = 0; i < winners.size(); i++) {
		}
		return new MaterialData(block.getType(), block.getData());
	}
	
/*	public static void main(String[] args) {
		final String meta = "Inventory";
		final List<Location> chestSpawns = new ArrayList<>();
		int count = 1; //How many chests you want to spawn
		int range = 1; //How far out you want to spawn them
		int spread = 1; //If you want to make sure that no two chests are two close to each other... this is the min distance.
		Location center = player.getLocation().setY(256);

		//Fair warning... if you were to set the range to 1 and the count to 20 or
		//something this would hang the server forever because it can't spawn 20 chests that close
		while (chestSpawns.size() < count) {
			double angle = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
			int hyp = ThreadLocalRandom.current().nextInt(range);
			double x = Math.sin(angle) / hyp;
			double y = Math.cos(angle) / hyp;
			directStream(center.clone().add(new Vector(x, y, 0)).getBlock(), DOWN)
					.filter(block -> block.getType().isSolid())
					.findAny()
					.map(Block::getLocation)
					.filter(location -> chestSpawns.stream()
							.map(location::distance)
							.noneMatch(distance -> distance < spread))
					.ifPresent(chestSpawns::add);
		}

		chestSpawns.forEach(chest -> {
			chest.getBlock().setType(Material.CHEST);
			chest.getBlock().setMetadata(meta, new LazyMetadataValue(plugin, () -> Bukkit.createInventory(null, 27)));
		});

		listen((PlayerInteractEvent event) -> {
			final Block block = event.getClickedBlock();
			if (chestSpawns.contains(block.getLocation())) {
				event.getPlayer().openInventory((Inventory) block.getMetadata(meta).get(0).value());
			}
		});
	}*/
	
	private static final BlockFace[] ORDERED = {
			NORTH, NORTH_EAST,
			EAST, SOUTH_EAST,
			SOUTH, SOUTH_WEST,
			WEST, NORTH_WEST
	};
	
	public static BlockFace direction(float yaw) {
		return ORDERED[round(yaw / 45f) & 0x3];
	}
	
	public static BlockFace direction(Entity entity) {
		return direction(entity.getLocation());
	}
	
	public static BlockFace direction(Location location) {
		return direction(location.getYaw());
	}
	
	public static void main(String[] args) {
		System.out.println(direction(90));
	}
	
	public static Stream<Block> dualDirectStream(Block block, BlockFace first, BlockFace second) {
		Iterator<Block> firstIterator = directIterator(block, first);
		Iterator<Block> secondIterator = directIterator(block, second);
		return StreamSupport.stream(((Iterable<Block>) () -> new Iterator<Block>() {
			boolean first = true;
			Block next = getNext();
			
			@Override
			public boolean hasNext() {
				return next != null;
			}
			
			@Override
			public Block next() {
				try {
					return next;
				} finally {
					next = getNext();
				}
			}
			
			private Block getNext() {
				if (first) {
					if (secondIterator.hasNext()) {
						first = false;
					}
					return firstIterator.next();
				} else {
					if (firstIterator.hasNext()) {
						first = true;
					}
					return secondIterator.next();
				}
			}
		}).spliterator(), false);
	}
	
	private static Iterator<Block> directIterator(Block block, BlockFace direction) {
		return new Iterator<Block>() {
			Block next = getNext();
			
			@Override
			public boolean hasNext() {
				return next != null;
			}
			
			@Override
			public Block next() {
				try {
					return next;
				} finally {
					next = getNext();
				}
			}
			
			private Block getNext() {
				if (block.getY() <= 0 || block.getY() >= 256) {
					return null;
				} else {
					return next.getRelative(direction);
				}
			}
		};
	}
	
	public static Stream<Block> directStream(Block block, BlockFace direction) {
		return StreamSupport.stream(((Iterable<Block>) () ->
				directIterator(block, direction)).spliterator(), false);
	}
	
	//--Location--
	@NotNull
	public static Optional<Block> directSearch(@NotNull Location location, BlockFace
			direction, @NotNull Predicate<Block> target) {
		return directSearch(location, () -> direction, target);
	}
	
	@NotNull
	public static Optional<Block> directSearch(@NotNull Location location, @NotNull Supplier<BlockFace> direction, @NotNull Predicate<Block> target) {
		return directSearch(location.getBlock(), direction, target);
	}
	
	@NotNull
	public static Optional<Block> directSearch(@NotNull Location location, BlockFace first, BlockFace
			second, @NotNull Predicate<Block> target) {
		return directSearch(location.getBlock(), first, second, target);
	}
	
	
	//Block--
	@NotNull
	public static Optional<Block> directSearch(@NotNull Block block, BlockFace first, BlockFace
			second, @NotNull Predicate<Block> target) {
		return directSearch(block, roundRobin(first, second), target);
	}
	
	@NotNull
	public static Optional<Block> directSearch(@NotNull Block
			                                           block, @NotNull Supplier<BlockFace> direction, @NotNull Predicate<Block> target) {
		do
			if (target.test(block)) {
				return of(block);
			}
		while ((block = block.getRelative(direction.get())) != null);
		return empty();
	}
	
	@NotNull
	public static List<Location> sphere(@NotNull Block center, int radius, boolean hollow) {
		return sphere(center.getLocation(), radius, hollow);
	}
	
	@NotNull
	public static List<Location> sphere(@NotNull Location center, int radius, boolean hollow) {
		List<Location> blocks = new ArrayList<Location>();
		int bx = center.getBlockX();
		int by = center.getBlockY();
		int bz = center.getBlockZ();
		
		for (int x = bx - radius; x <= bx + radius; x++) {
			for (int y = by - radius; y <= by + radius; y++) {
				for (int z = bz - radius; z <= bz + radius; z++) {
					
					double distance = ((bx - x) * (bx - x) + ((bz - z) * (bz - z)) + ((by - y) * (by - y)));
					
					if (distance < radius * radius && !(hollow && distance < ((radius - 1) * (radius - 1)))) {
						
						Location l = new Location(center.getWorld(), x, y, z);
						
						blocks.add(l);
						
					}
					
				}
			}
		}
		return blocks;
	}
}
