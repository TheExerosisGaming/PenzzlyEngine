package com.penzzly.engine.core.utilites;

public class UnsafeUtil {
//	public static Optional<Unsafe> getUnsafe() {
//		try {
//			Field f = Unsafe.class.getDeclaredField("theUnsafe");
//			f.setAccessible(true);
//			return of((Unsafe) f.get(null));
//		} catch (Exception e) {
//			return empty();
//		}
//	}
}
