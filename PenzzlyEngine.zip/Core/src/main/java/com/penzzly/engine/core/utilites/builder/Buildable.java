package com.penzzly.engine.core.utilites.builder;

public interface Buildable {
    void build();
}
