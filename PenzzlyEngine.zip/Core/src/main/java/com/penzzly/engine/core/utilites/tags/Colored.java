package com.penzzly.engine.core.utilites.tags;

import com.penzzly.engine.core.utilites.color.Palette;
import org.jetbrains.annotations.NotNull;

public interface Colored {
	@NotNull Palette getColor();
}
