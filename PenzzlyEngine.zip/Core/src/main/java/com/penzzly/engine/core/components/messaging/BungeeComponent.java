package com.penzzly.engine.core.components.messaging;

import com.penzzly.engine.architecture.base.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class BungeeComponent extends Component {
    private final PluginMessagingComponent messagingComponent;

    public BungeeComponent(PluginMessagingComponent messagingComponent) {
        this.messagingComponent = messagingComponent;
    }
    
    public void connect(@NotNull Player player, String server) {
        messagingComponent.sendMessage(player, "Connect", server);
    }
}
