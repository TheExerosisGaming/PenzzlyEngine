package com.penzzly.engine.core.base.configuration.serialization.alpha;

import com.penzzly.engine.architecture.base.Component;

public class TempFormat extends Component {
	private Object caller;
	
	public TempFormat unsafely(Object caller) {
		this.caller = caller;
		return this;
	}
	
	
}
