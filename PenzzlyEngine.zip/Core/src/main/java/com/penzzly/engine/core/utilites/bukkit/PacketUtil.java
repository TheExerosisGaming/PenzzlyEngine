package com.penzzly.engine.core.utilites.bukkit;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.penzzly.engine.architecture.base.Component;
import com.penzzly.engine.architecture.functions.compat.Consumer;
import com.penzzly.engine.architecture.utilites.Clarifiers;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.InvocationTargetException;

import static com.comphenix.protocol.PacketType.Play.Server.*;
import static com.comphenix.protocol.ProtocolLibrary.getProtocolManager;
import static com.penzzly.engine.architecture.utilites.Components.create;
import static com.penzzly.engine.core.utilites.bukkit.PlayerUtil.getOpenInventoryId;
import static com.penzzly.engine.core.utilites.bukkit.ServerUtil.getPlugin;

@SuppressWarnings("unchecked")
public final class PacketUtil {
	private PacketUtil() {
	
	}
	
	public static class Particle {
		private final String id;
		private int count = 0;
		private float data, x, y, z = 0;
		
		public Particle(String id) {
			this.id = id;
		}
		
		public static Particle create(String id) {
			return new Particle(id);
		}
		
		public Particle color(Color color) {
			return color(color.getRed(), color.getGreen(), color.getBlue());
		}
		
		public Particle color(Number red, Number green, Number blue) {
			x = red.intValue() / 255f;
			y = green.intValue() / 255f;
			z = blue.intValue() / 255f;
			return this;
		}
		
		public Particle offset(Vector vector) {
			x = (float) vector.getX();
			y = (float) vector.getY();
			z = (float) vector.getZ();
			return this;
		}
		
		public Particle offset(Number randSeed) {
			return offset(randSeed, randSeed, randSeed);
		}
		
		public Particle offset(Number x, Number y, Number z) {
			this.x = x.floatValue();
			this.y = y.floatValue();
			this.z = z.floatValue();
			return this;
		}
		
		public Particle data(float data) {
			this.data = data;
			return this;
		}
		
		public Particle count(Number count) {
			this.count = count.intValue();
			return this;
		}
	}
	
	public static void spawnParticle(Particle particle, Location location) {
		spawnParticle(particle, location.toVector());
	}
	
	public static void spawnParticle(Particle particle, Vector location) {
		spawnParticle(null, particle, location);
	}
	
	public static void spawnParticle(Player player, Particle particle, Location location) {
		spawnParticle(player, particle, location.toVector());
	}
	
	public static void spawnParticle(Player player, Particle particle, Vector location) {
		PacketContainer packet = getProtocolManager().createPacket(WORLD_PARTICLES);
		
		packet.getStrings().write(0, particle.id);
		packet.getFloat().write(0, (float) location.getX());
		packet.getFloat().write(1, (float) location.getY());
		packet.getFloat().write(2, (float) location.getZ());
		packet.getFloat().write(3, particle.x);
		packet.getFloat().write(4, particle.y);
		packet.getFloat().write(5, particle.z);
		packet.getFloat().write(3, 6f);
		packet.getFloat().write(4, 236f);
		packet.getFloat().write(5, 233f);
		packet.getFloat().write(6, particle.data);
		packet.getIntegers().write(0, particle.count);
		if (player != null) {
			sendSilently(player, packet);
		} else {
			broadcastSilently(packet);
		}
	}
	
	public static Component intercept(PacketType type, @NotNull Consumer<PacketEvent> packet) {
		PacketListener listener = new PacketAdapter(getPlugin(), type) {
			@Override
			public void onPacketReceiving(PacketEvent event) {
				packet.accept(event);
			}
			
			@Override
			public void onPacketSending(PacketEvent event) {
				packet.accept(event);
			}
		};
		return create(
				() -> getProtocolManager().addPacketListener(listener),
				() -> getProtocolManager().removePacketListener(listener)
		);
	}
	
	public static void sendTooltip(@NotNull Player player, @NotNull Object message) {
		ItemStack stack = player.getItemInHand().clone();
		ItemMeta meta = stack.getItemMeta();
		meta.setDisplayName(message.toString());
		stack.setItemMeta(meta);
		PacketContainer packet = getProtocolManager().createPacket(SET_SLOT);
		packet.getBytes().write(0, (byte) 0);
		packet.getShorts().write(0, (short) player.getInventory().getHeldItemSlot());
		packet.getItemModifier().write(0, stack);
		sendSilently(player, packet);
		packet.getItemModifier().write(0, player.getItemInHand());
		sendSilently(player, packet);
	}
	
	public static void sendActionBar(Player player, @NotNull Object message) {
//		PacketContainer packet = getProtocolManager().createPacket(CHAT);
//		packet.getChatComponents().write(0, fromText(message.toString()));
//		packet.getChatTypes().write(0, GAME_INFO);
//		sendSilently(player, packet);
	}
	
	public static void openInventory(@NotNull Player player, @NotNull String name, int size) {
		PacketContainer packet = getProtocolManager().createPacket(OPEN_WINDOW);
		getOpenInventoryId(player).ifPresent(id ->
				packet.getIntegers().write(0, id));
		packet.getStrings().write(0, "minecraft:chest");
		packet.getChatComponents().write(0, WrappedChatComponent.fromText(name));
		packet.getIntegers().write(1, size);
		sendSilently(player, packet);
	}
	
	public static void titleTimes(Player player, @NotNull @Clarifiers.Millis @Clarifiers.Long Number in, @NotNull @Clarifiers.Millis @Clarifiers.Long Number stay, @NotNull @Clarifiers.Millis @Clarifiers.Long Number out) {
//		PacketContainer packet = getProtocolManager().createPacket(Server.TITLE);
//		packet.getTitleActions().write(0, TIMES);
//		packet.getIntegers().write(0, in.intValue() * 20_000);
//		packet.getIntegers().write(1, stay.intValue() * 20_000);
//		packet.getIntegers().write(2, out.intValue() * 20_000);
//		sendSilently(player, packet);
	}
	
	public static void titleText(Player player, @NotNull @Clarifiers.Text Object title, Object action) {
//		PacketContainer packet = getProtocolManager().createPacket(Server.TITLE);
//		packet.getTitleActions().write(0, action);
//		packet.getChatComponents().write(0, fromText(title.toString()));
//		sendSilently(player, packet);
	}
	
	public static void titleReset(Player player, boolean hide) {
//		PacketContainer packet = getProtocolManager().createPacket(Server.TITLE);
//		packet.getTitleActions().write(0, hide ? CLEAR : RESET);
//		sendSilently(player, packet);
	}
	
	public static void receiveSilently(Player player, PacketContainer packet, boolean filters) {
		try {
			getProtocolManager().recieveClientPacket(player, packet, filters);
		} catch (Exception ignored) {
		}
	}
	
	public static void broadcastSilently(PacketContainer packet) {
		getProtocolManager().broadcastServerPacket(packet);
	}
	
	public static void sendSilently(Player player, PacketContainer packet) {
		try {
			getProtocolManager().sendServerPacket(player, packet);
		} catch (InvocationTargetException ignored) {
		}
	}
}