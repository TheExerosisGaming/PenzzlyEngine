package com.penzzly.engine.architecture.holder;
//TODO Document this package
//TODO Decide on Collection Holder.
//FIXME General improvements and testing.