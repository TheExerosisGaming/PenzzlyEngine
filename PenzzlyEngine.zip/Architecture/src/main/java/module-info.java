//module com.penzzly.engine.architecture {
//	requires guava;
//	requires javatuples;
//	requires java.base;
//	requires rxjava;
//	requires annotations;
//	requires jsr305;
//	exports com.penzzly.engine.architecture.base;
//	exports com.penzzly.engine.architecture.utilites;
//	exports com.penzzly.engine.architecture.functions;
//	exports com.penzzly.engine.architecture.holder;
//	exports com.penzzly.engine.architecture.holder.mutable;
//	exports com.penzzly.engine.architecture.functions.compat;
//}